# REALIZAR  UN BINGO DE 32 POCISIONES 
# 1. Solicitar al jugador su nombre
# 2. Mostrar el set de datos de forma de cartón (filas y columnas)
# 3. Empezar a jugar - ir eliminando números del cartón (primero)
# 4. Se debe ir guardando en una lista los números que se van eliminando 
# 5. Al final mostrar al player el orden en que se eliminaron los números

from queue import Empty
import random


print("Bienvenido a ¡Bingo!, donde podrá participar por asombrosos premios jugando bingo con nosotros") # Dar la bienvenida al usuario a neustro juego
playerNamer = input("Escriba aquí su nombre para empezar a jugar!: ") # Mostrar por consola un mensaje que invite al usuario a ingresar su nombre para poder empezar

# Crear un set llamado setNumber que almacenará las 32 posiciones del bingo
setNumbers = set(("47", "62", "95", "3", "6", "14", "24", "46", "63", "37", "4", "89", "56", "43", "17", "22", "76", "11", "51", "38", "10", "93", "33", "96", "27", "54", "75", "83", "23", "100", "15", "18")) # Llenamos el set con 32 posiciones nos números que el desarrollador decide
# Imprimir por consola un saludo para el usuario y el cartón con el que el usuario jugará bingo 
print("Hola {} ¿Cómo estás?".format(playerNamer))
print("Este es su cartón de juego con 32 posiciones!")



# Se hace un ciclo "for" para recorrer el set y poder mostrar por pantalla el cartón de juego
for i in range(0, 32, 4):
    setNumbers = tuple((setNumbers)) # Para poder imprimir el set en filas y columnas se pasará de tipo de variable "set" a "tuple"
    print("{}\t{}\t{}\t{}".format(setNumbers[i], setNumbers[i + 1], setNumbers[i + 2], setNumbers[i + 3])) # Se imprime el cartón del usuario en filas y columnas

setNumbers = set((setNumbers)) # Volvemos a convertir la tupla a set 

listDeleted = list(()) # Declaramos la lista que almacenará los valores que se vayan eliminando

# Preguntamos por consola al usuario si está listo para empezar a jugar el bingo
gameState = int(input("Está listo para empezar el bingo?\n(1) Si \n(0) No: "))
print("")

# Se imprime por consola que se empezará el juego y se mencionan acotaciones importantes para jugar 
print("Comencemos a jugar!\n")

# Se hace un bucle while para comprobar que el usuario quiera seguir jugando o no
while gameState == 1: 
    # Se hace un bucle for que hará que se "recorra" todo el set y de esta forma se irán eliminando números del setNumber
    for i in range(0, 32):
        print("\t\tRONDA {}".format(i + 1)) # Imprimimos por consola la ronda en la que se encuentra el usuario para mayor orientación en el juego 
        setNumbers = list((setNumbers)) #se convierte el set en una colección de datos de tipo list para poder aplicar la función random.choice
        #print(type(setNumbers)) //verificar que el set se convirtió en una lista
        x = random.choice(setNumbers)# Se selecciona un número aleatorio (con la función random.choice) de la colección de datos "SetNumbers", el númer se almacena en la variable x
        setNumbers = set((setNumbers)) #Convierte la lista setNumbers nuevamente en una colección de tipo set
        setNumbers.discard(x)#Se elimina un elemento en específico del set utilizando el metodo discard(), para evitar errores de tipo KeyError, el elemento corresponde a la variable x
        #x = setNumbers.pop() # La variable x hace referencia al número que será eliminado
        
        print("El número que se está jugando es: {} \n".format(x)) # Se imprime que número se está jugando y a la vez eliminando
        listDeleted.append(x) # Se agrega el número eliminado a la lista de los números eliminados

        print("Estos son los números que tiene en juego: \n{}".format(setNumbers)) # Se le muestra al usuario los números que aún no han salido y que por lo tanto siguen en juego

        
        gameState = int(input("Desea continuar jugando? \n(1) Si \n(0) No: ")) # Se pregunta y almacena por consola la decisión de si quiere o no seguir jugando 
        print("")
        if gameState == 0: # If para verificar el estado de la variable "gameState" y si esta es igual a 0 entonces que salga del ciclo "for"
            break
    break # Si se llega a este "break" significa que ya todas las rondas se hicieron y se puede salir del ciclo "while"

print("\nEl orden de los números eliminados fue: {}".format(listDeleted)) # Se imprime por consola la lista de los números en el orden que fueron eliminados 
input("\n\nPresiona cualquier tecla para cerrar el programa: ") 

"""
Desarrollado por:
Ana Sofia Mendez Ramirez
Miguel Angel Moreno Villanueva
Cristian Mateo Alvarez Posada

"""